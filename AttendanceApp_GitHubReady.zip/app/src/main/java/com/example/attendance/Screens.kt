package com.example.attendance

import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import java.io.File

// ───────────────────────── امروز (ثبت ورود/خروج) ─────────────────────────

@Composable
fun TodayScreen(db: Db, ver: Int, refresh: () -> Unit) {
    val emps = remember(ver) { db.employees() }
    val open = remember(ver) { db.openRecords() }
    val now = System.currentTimeMillis()
    val today = Jalali.dateStr(now)

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("امروز $today", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(12.dp))
        if (emps.isEmpty()) Text("ابتدا از تب «پرسنل» افراد را اضافه کنید.")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(emps, key = { it.id }) { e ->
                val r = open[e.id]
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(e.name, style = MaterialTheme.typography.titleMedium)
                            if (r == null) {
                                Text("خارج از محل")
                            } else {
                                val d = Jalali.dateStr(r.tIn)
                                val warn = if (d != today) "  ⚠ خروج روز قبل ثبت نشده" else ""
                                Text("حاضر از ${if (d != today) "$d " else ""}${Jalali.timeStr(r.tIn)}$warn")
                            }
                        }
                        Button(onClick = {
                            val t = System.currentTimeMillis()
                            if (r == null) db.checkIn(e.id, t) else db.checkOut(r.id, t)
                            refresh()
                        }) { Text(if (r == null) "ثبت ورود" else "ثبت خروج") }
                    }
                }
            }
        }
    }
}

// ───────────────────────── پرسنل ─────────────────────────

@Composable
fun StaffScreen(db: Db, ver: Int, refresh: () -> Unit) {
    val emps = remember(ver) { db.employees() }
    var name by remember { mutableStateOf("") }
    var toDelete by remember { mutableStateOf<Emp?>(null) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = name, onValueChange = { name = it },
                label = { Text("نام و نام خانوادگی") }, singleLine = true,
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = {
                if (name.isNotBlank()) { db.addEmployee(name); name = ""; refresh() }
            }) { Text("افزودن") }
        }
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(emps, key = { it.id }) { e ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(e.name, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                        TextButton(onClick = { toDelete = e }) { Text("حذف") }
                    }
                }
            }
        }
    }
    toDelete?.let { e ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("حذف ${e.name}؟") },
            text = { Text("سوابق قبلی در گزارش‌ها باقی می‌ماند.") },
            confirmButton = { TextButton(onClick = { db.deactivate(e.id); toDelete = null; refresh() }) { Text("حذف") } },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("انصراف") } }
        )
    }
}

// ───────────────────────── گزارش ماهانه ─────────────────────────

private data class Summary(val empId: Long, val name: String, val recs: List<Rec>) {
    val minutes: Long get() = recs.sumOf { r -> r.tOut?.let { (it - r.tIn) / 60_000 } ?: 0L }
    val days: Int get() = recs.map { Jalali.dateStr(it.tIn) }.distinct().size
    val openCount: Int get() = recs.count { it.tOut == null }
}

@Composable
fun ReportScreen(db: Db, ver: Int, refresh: () -> Unit) {
    val ctx = LocalContext.current
    val nowJ = remember { Jalali.fromMillis(System.currentTimeMillis()) }
    var jy by remember { mutableIntStateOf(nowJ[0]) }
    var jm by remember { mutableIntStateOf(nowJ[1]) }
    var selected by remember { mutableStateOf<Long?>(null) }
    var dialog by remember { mutableStateOf<Pair<Long, Rec?>?>(null) }

    val names = remember(ver) { db.employeeNames() }
    val summaries = remember(jy, jm, ver) {
        db.records(Jalali.startOfMonth(jy, jm), Jalali.startOfNextMonth(jy, jm))
            .groupBy { it.empId }
            .map { (id, rs) -> Summary(id, names[id] ?: "؟", rs) }
            .sortedBy { it.name }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = {
                if (jm == 1) { jm = 12; jy-- } else jm--
                selected = null
            }) { Text("ماه قبل") }
            Text(
                "${Jalali.monthNames[jm - 1]} $jy",
                Modifier.weight(1f),
                style = MaterialTheme.typography.titleLarge,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
            TextButton(onClick = {
                if (jm == 12) { jm = 1; jy++ } else jm++
                selected = null
            }) { Text("ماه بعد") }
        }

        val sel = summaries.firstOrNull { it.empId == selected }
        if (sel == null) {
            if (summaries.isEmpty()) Text("در این ماه سابقه‌ای ثبت نشده است.")
            else {
                Row(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                    Text("نام", Modifier.weight(2f), style = MaterialTheme.typography.labelLarge)
                    Text("روز", Modifier.weight(1f), style = MaterialTheme.typography.labelLarge)
                    Text("مجموع (ساعت:دقیقه)", Modifier.weight(2f), style = MaterialTheme.typography.labelLarge)
                }
                HorizontalDivider()
                LazyColumn(Modifier.weight(1f)) {
                    items(summaries, key = { it.empId }) { s ->
                        Row(
                            Modifier.fillMaxWidth().clickable { selected = s.empId }.padding(vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(s.name + if (s.openCount > 0) " ⚠" else "", Modifier.weight(2f))
                            Text("${s.days}", Modifier.weight(1f))
                            Text(Jalali.duration(s.minutes), Modifier.weight(2f))
                        }
                        HorizontalDivider()
                    }
                }
                val total = summaries.sumOf { it.minutes }
                Text("مجموع کل: ${Jalali.duration(total)}", Modifier.padding(vertical = 8.dp),
                    style = MaterialTheme.typography.titleMedium)
                if (summaries.any { it.openCount > 0 })
                    Text("⚠ یعنی خروج ثبت‌نشده دارد؛ روی نام بزنید و اصلاح کنید. این موارد در مجموع حساب نشده‌اند.",
                        style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(8.dp))
                Button(onClick = { shareCsv(ctx, jy, jm, summaries) }, Modifier.fillMaxWidth()) {
                    Text("خروجی اکسل (CSV) و ارسال")
                }
            }
        } else {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { selected = null }) { Text("بازگشت") }
                Text(sel.name, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                Text(Jalali.duration(sel.minutes))
            }
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(sel.recs, key = { it.id }) { r ->
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(Jalali.dateStr(r.tIn))
                                Text(
                                    "ورود ${Jalali.timeStr(r.tIn)}  •  خروج " +
                                            (r.tOut?.let { Jalali.timeStr(it) } ?: "ثبت نشده ⚠") +
                                            (r.tOut?.let { "  •  " + Jalali.duration((it - r.tIn) / 60_000) } ?: "")
                                )
                            }
                            TextButton(onClick = { dialog = sel.empId to r }) { Text("ویرایش") }
                            TextButton(onClick = { db.deleteRecord(r.id); refresh() }) { Text("حذف") }
                        }
                    }
                }
            }
        }
        if (summaries.isEmpty() || sel != null) {
            Spacer(Modifier.height(8.dp))
            val target = sel?.empId ?: db.employees().firstOrNull()?.id
            OutlinedButton(
                onClick = { target?.let { dialog = it to null } },
                Modifier.fillMaxWidth(),
                enabled = target != null
            ) { Text(if (sel != null) "افزودن دستی سابقه برای ${sel.name}" else "افزودن دستی سابقه") }
        }
    }

    dialog?.let { (empId, rec) ->
        RecordDialog(
            rec = rec,
            onDismiss = { dialog = null },
            onSave = { tIn, tOut ->
                if (rec == null) db.addRecord(empId, tIn, tOut) else db.updateRecord(rec.id, tIn, tOut)
                dialog = null; refresh()
            }
        )
    }
}

@Composable
private fun RecordDialog(rec: Rec?, onDismiss: () -> Unit, onSave: (Long, Long?) -> Unit) {
    val ctx = LocalContext.current
    var date by remember { mutableStateOf(Jalali.dateStr(rec?.tIn ?: System.currentTimeMillis())) }
    var tin by remember { mutableStateOf(rec?.let { Jalali.timeStr(it.tIn) } ?: "08:00") }
    var tout by remember { mutableStateOf(rec?.tOut?.let { Jalali.timeStr(it) } ?: "") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (rec == null) "افزودن سابقه" else "ویرایش سابقه") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(date, { date = it }, label = { Text("تاریخ ورود (مثلا 1405/09/01)") }, singleLine = true)
                OutlinedTextField(tin, { tin = it }, label = { Text("ساعت ورود (08:30)") }, singleLine = true)
                OutlinedTextField(tout, { tout = it }, label = { Text("ساعت خروج (خالی = ثبت نشده)") }, singleLine = true)
                Text("اگر خروج از ورود کوچک‌تر باشد، روز بعد در نظر گرفته می‌شود.", style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val a = Jalali.parse(date, tin)
                if (a == null) { Toast.makeText(ctx, "تاریخ یا ساعت ورود نامعتبر است", Toast.LENGTH_SHORT).show(); return@TextButton }
                var b: Long? = null
                if (tout.isNotBlank()) {
                    b = Jalali.parse(date, tout)
                    if (b == null) { Toast.makeText(ctx, "ساعت خروج نامعتبر است", Toast.LENGTH_SHORT).show(); return@TextButton }
                    if (b <= a) b += 24L * 60 * 60 * 1000
                }
                onSave(a, b)
            }) { Text("ذخیره") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } }
    )
}

// ───────────────────────── خروجی CSV ─────────────────────────

private fun shareCsv(ctx: Context, jy: Int, jm: Int, summaries: List<Summary>) {
    val sb = StringBuilder()
    sb.append("گزارش ${Jalali.monthNames[jm - 1]} $jy\n")
    sb.append("نام,تاریخ,ورود,خروج,مدت (ساعت:دقیقه)\n")
    for (s in summaries) {
        val name = s.name.replace(",", " ")
        for (r in s.recs) {
            sb.append("$name,${Jalali.dateStr(r.tIn)},${Jalali.timeStr(r.tIn)},")
            sb.append(r.tOut?.let { Jalali.timeStr(it) } ?: "ثبت نشده").append(',')
            sb.append(r.tOut?.let { Jalali.duration((it - r.tIn) / 60_000) } ?: "").append('\n')
        }
        sb.append("$name,جمع ${s.days} روز,,,${Jalali.duration(s.minutes)}\n")
    }
    sb.append("جمع کل,,,,${Jalali.duration(summaries.sumOf { it.minutes })}\n")

    val f = File(ctx.cacheDir, "report_${jy}_${"%02d".format(jm)}.csv")
    f.writeText("﻿" + sb.toString(), Charsets.UTF_8) // BOM برای نمایش درست فارسی در اکسل
    val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)
    val i = Intent(Intent.ACTION_SEND).apply {
        type = "text/csv"
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    ctx.startActivity(Intent.createChooser(i, "ارسال گزارش"))
}
