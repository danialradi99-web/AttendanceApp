package com.example.attendance

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class Emp(val id: Long, val name: String)
data class Rec(val id: Long, val empId: Long, val tIn: Long, val tOut: Long?)

class Db(ctx: Context) : SQLiteOpenHelper(ctx, "attendance.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE employee(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1)")
        db.execSQL("CREATE TABLE record(id INTEGER PRIMARY KEY AUTOINCREMENT, emp_id INTEGER NOT NULL, t_in INTEGER NOT NULL, t_out INTEGER)")
        db.execSQL("CREATE INDEX idx_record_in ON record(t_in)")
    }

    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {}

    fun employees(): List<Emp> {
        val out = mutableListOf<Emp>()
        readableDatabase.rawQuery("SELECT id, name FROM employee WHERE active=1 ORDER BY name", null).use {
            while (it.moveToNext()) out += Emp(it.getLong(0), it.getString(1))
        }
        return out
    }

    /** نام همه پرسنل (حتی حذف‌شده‌ها) برای نمایش در گزارش‌های قدیمی */
    fun employeeNames(): Map<Long, String> {
        val m = mutableMapOf<Long, String>()
        readableDatabase.rawQuery("SELECT id, name FROM employee", null).use {
            while (it.moveToNext()) m[it.getLong(0)] = it.getString(1)
        }
        return m
    }

    fun addEmployee(name: String) {
        writableDatabase.insert("employee", null, ContentValues().apply { put("name", name.trim()) })
    }

    /** حذف پرسنل: فقط غیرفعال می‌شود تا سوابق گزارش‌ها حفظ شود */
    fun deactivate(id: Long) {
        writableDatabase.update("employee", ContentValues().apply { put("active", 0) }, "id=?", arrayOf(id.toString()))
    }

    private fun rec(c: android.database.Cursor) =
        Rec(c.getLong(0), c.getLong(1), c.getLong(2), if (c.isNull(3)) null else c.getLong(3))

    /** رکوردهای بدون خروج (کسانی که الان حاضرند) */
    fun openRecords(): Map<Long, Rec> {
        val m = mutableMapOf<Long, Rec>()
        readableDatabase.rawQuery("SELECT id, emp_id, t_in, t_out FROM record WHERE t_out IS NULL", null).use {
            while (it.moveToNext()) { val r = rec(it); m[r.empId] = r }
        }
        return m
    }

    fun checkIn(empId: Long, now: Long) {
        writableDatabase.insert("record", null, ContentValues().apply {
            put("emp_id", empId); put("t_in", now)
        })
    }

    fun checkOut(recId: Long, now: Long) {
        writableDatabase.update("record", ContentValues().apply { put("t_out", now) }, "id=?", arrayOf(recId.toString()))
    }

    fun records(from: Long, to: Long): List<Rec> {
        val out = mutableListOf<Rec>()
        readableDatabase.rawQuery(
            "SELECT id, emp_id, t_in, t_out FROM record WHERE t_in>=? AND t_in<? ORDER BY t_in",
            arrayOf(from.toString(), to.toString())
        ).use { while (it.moveToNext()) out += rec(it) }
        return out
    }

    fun addRecord(empId: Long, tIn: Long, tOut: Long?) {
        writableDatabase.insert("record", null, ContentValues().apply {
            put("emp_id", empId); put("t_in", tIn)
            if (tOut == null) putNull("t_out") else put("t_out", tOut)
        })
    }

    fun updateRecord(id: Long, tIn: Long, tOut: Long?) {
        writableDatabase.update("record", ContentValues().apply {
            put("t_in", tIn)
            if (tOut == null) putNull("t_out") else put("t_out", tOut)
        }, "id=?", arrayOf(id.toString()))
    }

    fun deleteRecord(id: Long) {
        writableDatabase.delete("record", "id=?", arrayOf(id.toString()))
    }
}
