package com.example.attendance

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = Db(applicationContext)
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MaterialTheme { App(db) }
            }
        }
    }
}

@Composable
fun App(db: Db) {
    var tab by remember { mutableIntStateOf(0) }
    var ver by remember { mutableIntStateOf(0) }
    val refresh = { ver++ }
    Scaffold(
        bottomBar = {
            NavigationBar {
                listOf("امروز", "پرسنل", "گزارش ماهانه").forEachIndexed { i, t ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = {}, label = { Text(t) })
                }
            }
        }
    ) { pad ->
        androidx.compose.foundation.layout.Box(Modifier.padding(pad)) {
            when (tab) {
                0 -> TodayScreen(db, ver, refresh)
                1 -> StaffScreen(db, ver, refresh)
                else -> ReportScreen(db, ver, refresh)
            }
        }
    }
}
