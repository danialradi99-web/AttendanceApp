package com.example.attendance

import java.util.Calendar

/** تبدیل تاریخ میلادی/شمسی و ابزارهای زمان */
object Jalali {
    val monthNames = listOf(
        "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
        "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"
    )

    fun toJalali(gy: Int, gm: Int, gd: Int): IntArray {
        val gdm = intArrayOf(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334)
        val gy2 = if (gm > 2) gy + 1 else gy
        var days = 355666 + (365 * gy) + ((gy2 + 3) / 4) - ((gy2 + 99) / 100) +
                ((gy2 + 399) / 400) + gd + gdm[gm - 1]
        var jy = -1595 + (33 * (days / 12053))
        days %= 12053
        jy += 4 * (days / 1461)
        days %= 1461
        if (days > 365) {
            jy += (days - 1) / 365
            days = (days - 1) % 365
        }
        val jm: Int
        val jd: Int
        if (days < 186) {
            jm = 1 + days / 31; jd = 1 + days % 31
        } else {
            jm = 7 + (days - 186) / 30; jd = 1 + (days - 186) % 30
        }
        return intArrayOf(jy, jm, jd)
    }

    fun toGregorian(jy: Int, jm: Int, jd: Int): IntArray {
        val jy2 = jy + 1595
        var days = -355668 + (365 * jy2) + ((jy2 / 33) * 8) + (((jy2 % 33) + 3) / 4) + jd +
                (if (jm < 7) (jm - 1) * 31 else ((jm - 7) * 30) + 186)
        var gy = 400 * (days / 146097)
        days %= 146097
        if (days > 36524) {
            days--
            gy += 100 * (days / 36524)
            days %= 36524
            if (days >= 365) days++
        }
        gy += 4 * (days / 1461)
        days %= 1461
        if (days > 365) {
            gy += (days - 1) / 365
            days = (days - 1) % 365
        }
        var gd = days + 1
        val leap = (gy % 4 == 0 && gy % 100 != 0) || gy % 400 == 0
        val sal = intArrayOf(0, 31, if (leap) 29 else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
        var gm = 0
        while (gm < 13 && gd > sal[gm]) {
            gd -= sal[gm]; gm++
        }
        return intArrayOf(gy, gm, gd)
    }

    /** زمان به‌صورت میلی‌ثانیه -> [سال، ماه، روز] شمسی */
    fun fromMillis(t: Long): IntArray {
        val c = Calendar.getInstance().apply { timeInMillis = t }
        return toJalali(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
    }

    fun dateStr(t: Long): String {
        val j = fromMillis(t)
        return "%04d/%02d/%02d".format(j[0], j[1], j[2])
    }

    fun timeStr(t: Long): String {
        val c = Calendar.getInstance().apply { timeInMillis = t }
        return "%02d:%02d".format(c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE))
    }

    /** شروع روز شمسی (۰۰:۰۰) به میلی‌ثانیه */
    fun startOfDay(jy: Int, jm: Int, jd: Int): Long {
        val g = toGregorian(jy, jm, jd)
        return Calendar.getInstance().apply {
            clear()
            set(g[0], g[1] - 1, g[2], 0, 0, 0)
        }.timeInMillis
    }

    /** شروع ماه شمسی */
    fun startOfMonth(jy: Int, jm: Int): Long = startOfDay(jy, jm, 1)

    fun startOfNextMonth(jy: Int, jm: Int): Long =
        if (jm == 12) startOfMonth(jy + 1, 1) else startOfMonth(jy, jm + 1)

    /** تاریخ شمسی (۱۴۰۵/۰۹/۰۱) + ساعت (08:30) -> میلی‌ثانیه؛ null در صورت خطا */
    fun parse(date: String, time: String): Long? {
        return try {
            val d = date.trim().replace('-', '/').split("/").map { it.trim().toInt() }
            val t = time.trim().split(":").map { it.trim().toInt() }
            if (d.size != 3 || t.size != 2) return null
            if (d[1] !in 1..12 || d[2] !in 1..31 || t[0] !in 0..23 || t[1] !in 0..59) return null
            startOfDay(d[0], d[1], d[2]) + (t[0] * 60L + t[1]) * 60_000L
        } catch (e: Exception) {
            null
        }
    }

    fun duration(minutes: Long): String = "%d:%02d".format(minutes / 60, minutes % 60)
}
